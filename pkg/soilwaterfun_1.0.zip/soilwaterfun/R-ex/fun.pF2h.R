### Name: fun.pF2h
### Title: Converts pF to h
### Aliases: fun.pF2h


### ** Examples
require( "soilwaterfun" )

fun.pF2h( pF = c(0,2,4.2) ) 


