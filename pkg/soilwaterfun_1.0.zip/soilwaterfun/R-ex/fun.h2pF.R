### Name: fun.h2pF
### Title: Converts h to pF
### Aliases: fun.h2pF


### ** Examples
require( "soilwaterfun" )

fun.h2pF( h = fun.pF2h( pF = c(0,2,4.2) ) )


