fun.brooks.corey.theta.h    package:soilwaterfun    R Documentation

_B_r_o_o_k_s & _C_o_r_e_y _1_9_6_4 _f_u_n_c_t_i_o_n _f_o_r _w_a_t_e_r _r_e_t_e_n_s_i_o_n, _t_h_e_t_a(_h)

_D_e_s_c_r_i_p_t_i_o_n:

     Brooks and Corey 1964 model for soil water retension.  The model
     is: theta.e = (h/hA)^-lambda with  theta.e = (theta - thetaR) /
     (thetaS - thetaR) when h < hA  and theta = thetaS when hA <= h < 0

_U_s_a_g_e:

     fun.brooks.corey.theta.h(h, hA, thetaS, thetaR, lambda)

_A_r_g_u_m_e_n_t_s:

       h: Vector of numerical. Matrix potential of the soil, in [m]. 
          Values should be negative (suction).

      hA: Single numerical. Matrix potential at the air entry point
          [m],  negative.

  thetaS: Single numerical. Soil saturated water content [m3.m-3].

  thetaR: Single numerical. Soil residual water content [m3.m-3].

  lambda: Single numerical. Brook & Corey lambda (shape) parameter [-] 
          (pore size distribution index, approx. from 2 to 5). 

_V_a_l_u_e:

     Returns a vector of numericals, theta [m3.m-3] for each h  values
     provided.

_A_u_t_h_o_r(_s):

     Julien MOEYS <jules_m78-soiltexture@yahoo.fr>

_R_e_f_e_r_e_n_c_e_s:

     Brooks & Corey, 1964. Hydraulic properties of porous  media.
     Colorado State University, Fort Collins, USA. Hydrology  paper, 3;
      Kutilek M. & Nielsen D.R., 1994. Soil hydrology. Catena-Verlag, 
     GeoEcology textbook, Germany. ISBN : 9-923381-26-3., 370 p.

_E_x_a_m_p_l_e_s:

     require( "soilwaterfun" ) 

     fun.brooks.corey.theta.h( 
         h       = seq( from = 0, to = -10, by = -0.1 ), 
         hA      = -0.01, 
         thetaS  = 0.5, 
         thetaR  = 0.1, 
         lambda  = 3 
     )   #

     curve( 
         fun.brooks.corey.theta.h( 
             h       = -x, 
             hA      = -0.01, 
             thetaS  = 0.5, 
             thetaR  = 0.1, 
             lambda  = 3 
         ), 
         xlim = c(0.001,10), 
         col  = "red", 
         log  = "x", 
         xlab = "-h", 
         ylab = expression( theta )
     )   #
     abline( v = 0.01 )

