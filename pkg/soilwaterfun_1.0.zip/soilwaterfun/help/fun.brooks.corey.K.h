fun.brooks.corey.K.h      package:soilwaterfun      R Documentation

_B_r_o_o_k_s & _C_o_r_e_y _1_9_6_4 _f_u_n_c_t_i_o_n _f_o_r _h_y_d_r_a_u_l_i_c _c_o_n_d_u_c_t_i_v_i_t_y, _K(_h)

_D_e_s_c_r_i_p_t_i_o_n:

     Brooks and Corey 1964 model for soil hydraulic conductivity.  The
     model is: K / Ks = (h/hA)^-m when h < hA  and K = Ks when hA <= h
     < 0

_U_s_a_g_e:

     fun.brooks.corey.K.h(h, hA, Ks, m)

_A_r_g_u_m_e_n_t_s:

       h: Vector of numerical. Matrix potential of the soil, in [m]. 
          Values should be negative (suction).

      hA: Single numerical. Matrix potential at the air entry point
          [m3.m-3]

      Ks: Single numerical. Soil saturated hydraulic conductivity. In 
          length unit per unit of time [L.T-1] (the unit in which K is 
          resturned is the same as the unit in which Ks is given). 

       m: Single numerical. Brook & Corey m (shape) parameter [-] 
          (depend on the pore size distribution. approx. from 3 to 11). 

_V_a_l_u_e:

     Returns a vector of numericals, K values [L.T-1] (same unit as 
     Ks) for each h values provided.

_A_u_t_h_o_r(_s):

     Julien MOEYS <jules_m78-soiltexture@yahoo.fr>

_R_e_f_e_r_e_n_c_e_s:

     Brooks & Corey, 1964. Hydraulic properties of porous  media.
     Colorado State University, Fort Collins, USA. Hydrology  paper, 3;
      Kutilek M. & Nielsen D.R., 1994. Soil hydrology. Catena-Verlag, 
     GeoEcology textbook, Germany. ISBN : 9-923381-26-3., 370 p.

_E_x_a_m_p_l_e_s:

     require("soilwaterfun") 

     fun.brooks.corey.K.h( 
         h       = seq(from=0,to=-10,by=-0.1), 
         hA      = -0.01, 
         Ks      = 10, 
         m       = 6 
     )   #

     curve( 
         fun.brooks.corey.K.h( 
             h       = -x, 
             hA      = -0.01, 
             Ks      = 10, 
             m       = 6 
         ),  #
         xlim = c(0.001,10), 
         col  = "red", 
         log  = "xy", 
         xlab = "-h", 
         ylab = "K"
     )   #
     abline( v = 0.01 )

