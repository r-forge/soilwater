fun.vangenuchten.se.h      package:soilwaterfun      R Documentation

_v_a_n _G_e_n_u_c_h_t_e_n _1_9_8_0'_s _f_u_n_c_t_i_o_n _f_o_r _s_o_i_l _r_e_l_a_t_i_v_e _s_a_t_u_r_a_t_i_o_n.

_D_e_s_c_r_i_p_t_i_o_n:

     Calculate the relative saturation Se of a soil at a given  tension
     h with the Van Genuchten water retention function.

_U_s_a_g_e:

     fun.vangenuchten.se.h(h, alpha, n, cPar = 1)

_A_r_g_u_m_e_n_t_s:

       h: Vector of numerical. Matrix potential of the soil, in [m]. 
          Values should be negative (suction).

   alpha: Single numerical. alpha (shape) parameter of the Van
          Genuchten  water retention function, in [m-1] (inverse length
          unit of h).

       n: Single numerical. n shape parameter of the Van Genuchten
          water  retention function, dimensionless [-]. See also the
          'cPar'  parameter that, along with 'n', is used to calculate
          van Genuchten's  m parameter.

    cPar: Single numerical. Value of the c parameter of the Van
          Genuchten  water retention function, that allows to calculate
          the m parameter  so m = (1 - cPar/n). Dimensionless [-].
          Usually fixed / constant.

_V_a_l_u_e:

     The function returns the relative water content (degree of 
     saturation, Se, [-]).

_A_u_t_h_o_r(_s):

     Julien MOEYS <jules_m78-soiltexture@yahoo.fr>

_R_e_f_e_r_e_n_c_e_s:

     van Genuchten M. Th., 1980. A closed form equation  for predicting
     the hydraulic conductivity of unsaturated soils.  Soil Science
     Society of America Journal, 44:892-898. Kutilek M. & Nielsen D.R.,
     1994. Soil hydrology.  Catena-Verlag, GeoEcology textbook,
     Germany. ISBN:  9-923381-26-3., 370 p.

_E_x_a_m_p_l_e_s:

     require( "soilwaterfun" ) 

     # Example with the properties of the Footprint soil type P22i, 
     # 3rd layer:
     fun.vangenuchten.se.h( 
         h       = -c(0,0.01,0.1,1,10,100,158), 
         alpha   = 3.561099, 
         n       = 1.212074  
     )   #

