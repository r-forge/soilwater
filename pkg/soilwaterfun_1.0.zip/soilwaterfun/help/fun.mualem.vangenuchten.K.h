fun.mualem.vangenuchten.K.h   package:soilwaterfun   R Documentation

_M_u_a_l_e_m (_1_9_7_6) & _v_a_n _G_e_n_u_c_h_t_e_n (_1_9_8_0)'_s _f_u_n_c_t_i_o_n _K(_h) (_h_y_d_r_a_u_l_i_c _c_o_n_d_u_c_t_i_v_i_t_y).

_D_e_s_c_r_i_p_t_i_o_n:

     Calculate soil hydraulic conductivity at a given tension h  with
     the Mualem - Van Genuchten function.

_U_s_a_g_e:

     fun.mualem.vangenuchten.K.h(h, Ks, alpha, n, a = 2, b = 0.5, cPar = 1)

_A_r_g_u_m_e_n_t_s:

       h: Vector of numerical. Matrix potential of the soil, in [m]. 
          Values should be negative (suction).

      Ks: Single numerical. Saturated hydraulic conductivity of the
          soil  in [L.T-1] (unit of length per unit of time). The K
          result is  outputed in the same unit as Ks. Notice that in
          some case a  distinction is made between K(h=0) and
          K(saturation), and 'Ks'  should / may be considered as
          K(h=0).

   alpha: Single numerical. alpha (shape) parameter of the Van
          Genuchten  water retention function, in [m-1] (inverse length
          unit of h).

       n: Single numerical. n shape parameter of the Van Genuchten
          water  retention function, dimensionless [-]. See also the
          'cPar'  parameter that, along with 'n', is used to calculate
          van Genuchten's  m parameter.

       a: Single numerical. Value of the a parameter of the Mualem -
          Van  Genuchten hydraulic conductivity function. Dimensionless
          [-]??.  a = 2 in the Mualem formulation, and 1 in the Burdine
          formulation.

       b: Single numerical. Value of the b parameter of the Mualem -
          Van  Genuchten hydraulic conductivity function. Dimensionless
          [-]??.  b = 0.5 in the Mualem formulation, and 2 in the
          Burdine formulation. Notice that Schaaps et al.'s Rosetta 1.2
          and Wosten et al. 1999  are using the symbol 'L' (or 'l')
          instead of 'b'. 'b' is a  tortuosity or connectivity
          parameter (Rosetta 1.2). 

    cPar: Single numerical. Value of the c parameter of the Van
          Genuchten  water retention function, that allows to calculate
          the m parameter  so that m = (1 - cPar/n). Dimensionless [-].
          cPar = 1 in the  Mualem formulation, and 2 in the Burdine
          formulation.

_V_a_l_u_e:

     Returns K, the hydraulic conductivity (in [L.T-1], same unit  as
     Ks), for each h value provided.

_A_u_t_h_o_r(_s):

     Julien MOEYS <jules_m78-soiltexture@yahoo.fr>

_R_e_f_e_r_e_n_c_e_s:

     van Genuchten M. Th., 1980. A closed form equation  for predicting
     the hydraulic conductivity of unsaturated soils.  Soil Science
     Society of America Journal, 44:892-898.  Mualem Y., 1976. A new
     model for predicting the hydraulic  conductivity of unsaturated
     porous media. Water Resources  Research, 12:513-522.  Kutilek M. &
     Nielsen D.R., 1994. Soil hydrology.  Catena-Verlag, GeoEcology
     textbook, Germany. ISBN:  9-923381-26-3., 370 p.

_E_x_a_m_p_l_e_s:

     require( "soilwaterfun" ) 

     # Example with the properties of the Footprint soil type P22i, 
     # 3rd layer:
     fun.mualem.vangenuchten.K.h( 
         h       = -c(0,0.01,0.1,1,10,100,158), 
         Ks      = 28.27612, 
         alpha   = 3.561099, 
         n       = 1.212074  
     )   #

     curve( 
         fun.mualem.vangenuchten.K.h( 
             h       = -x, 
             Ks      = 28.27612, 
             alpha   = 3.561099, 
             n       = 1.212074  
         ),  #
         xlim = c(0.001,158), 
         col  = "red", 
         log  = "xy", 
         xlab = "-h", 
         ylab = "K"
     )   #

