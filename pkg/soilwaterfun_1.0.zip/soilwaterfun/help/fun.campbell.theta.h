fun.campbell.theta.h      package:soilwaterfun      R Documentation

_C_a_m_p_b_e_l_l _1_9_7_4 _f_u_n_c_t_i_o_n _f_o_r _w_a_t_e_r _r_e_t_e_n_s_i_o_n, _t_h_e_t_a(_h)

_D_e_s_c_r_i_p_t_i_o_n:

     Function that calculates soil water content theta after  Campbell
     1974 equation, a simplification of Brooks and Corey  1964 equation
     used in fun.brooks.corey.theta.h(), with thetaR  fixed to 0. The
     model is: theta / thetaS = (h/hA)^-(1/bPar) when h < hA  and theta
     = thetaS when hA <= h < 0 The advantage of Campbell's model is
     that it uses the same  bPar parameter for both the water retention
     curve and  the hydraulic conductivity.

_U_s_a_g_e:

     fun.campbell.theta.h(h, hA, thetaS, bPar)

_A_r_g_u_m_e_n_t_s:

       h: Vector of numerical. Matrix potential of the soil, in [m]. 
          Values should be negative (suction).

      hA: Single numerical. Matrix potential at the air entry point
          [m3.m-3]

  thetaS: Single numerical. Soil saturated water content [m3.m-3].

    bPar: Single numerical. Campbell 'b' (shape) parameter (corresponds
           to 1/lambda, where lambda is Brooks & Corey pore size 
          distribution index). 

_V_a_l_u_e:

     Returns a vector of numericals, theta [m3.m-3] for each h  values
     provided.

_A_u_t_h_o_r(_s):

     Julien MOEYS <jules_m78-soiltexture@yahoo.fr>

_R_e_f_e_r_e_n_c_e_s:

     Brooks & Corey, 1964. Hydraulic properties of porous  media.
     Colorado State University, Fort Collins, USA. Hydrology  paper, 3;
      Kutilek M. & Nielsen D.R., 1994. Soil hydrology. Catena-Verlag, 
     GeoEcology textbook, Germany. ISBN : 9-923381-26-3., 370 p.
     Campbell, 1974. A simple-method for determining  unsaturated
     conductivity from moisture retention data.  Soil Science 117:6.
     pp. 311-314

_E_x_a_m_p_l_e_s:

     require("soilwaterfun") 

     fun.campbell.theta.h( 
         h       = seq(from=0,to=-10,by=-0.1), 
         hA      = -0.01, 
         thetaS  = 0.5, 
         bPar    = 1/3 
     )   #

     curve( 
         fun.campbell.theta.h( 
             h       = -x, 
             hA      = -0.01, 
             thetaS  = 0.5, 
             bPar    = 1/3 
         ), 
         xlim = c(0.001,10), 
         col  = "red", 
         log  = "x", 
         xlab = "-h", 
         ylab = expression( theta )
     )   #
     abline( v = 0.01 )

