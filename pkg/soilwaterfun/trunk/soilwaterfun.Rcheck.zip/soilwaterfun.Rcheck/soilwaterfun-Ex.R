pkgname <- "soilwaterfun"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
options(pager = "console")
library('soilwaterfun')

assign(".oldSearch", search(), pos = 'CheckExEnv')
cleanEx()
nameEx("fun.brooks.corey.K.h")
### * fun.brooks.corey.K.h

flush(stderr()); flush(stdout())

### Name: fun.brooks.corey.K.h
### Title: Brooks & Corey 1964 function for hydraulic conductivity, K(h)
### Aliases: fun.brooks.corey.K.h

### ** Examples
require("soilwaterfun") 

fun.brooks.corey.K.h( 
    h       = seq(from=0,to=-10,by=-0.1), 
    h.a     = -0.01, 
    Ks      = 10, 
    m       = 6 
)   #

curve( 
    fun.brooks.corey.K.h( 
        h       = -x, 
        h.a     = -0.01, 
        Ks      = 10, 
        m       = 6 
    ),  #
    xlim = c(0.001,10), 
    col  = "red", 
    log  = "xy", 
    xlab = "-h", 
    ylab = "K"
)   #
abline( v = 0.01 )


cleanEx()
nameEx("fun.brooks.corey.theta.h")
### * fun.brooks.corey.theta.h

flush(stderr()); flush(stdout())

### Name: fun.brooks.corey.theta.h
### Title: Brooks & Corey 1964 function for water retension, theta(h)
### Aliases: fun.brooks.corey.theta.h

### ** Examples
require( "soilwaterfun" ) 

fun.brooks.corey.theta.h( 
    h       = seq(from=0,to=-10,by=-0.1), 
    h.a     = -0.01, 
    theta.s = 0.5, 
    theta.r = 0.1, 
    lambda  = 3 
)   #

curve( 
    fun.brooks.corey.theta.h( 
        h       = -x, 
        h.a     = -0.01, 
        theta.s = 0.5, 
        theta.r = 0.1, 
        lambda  = 3 
    ), 
    xlim = c(0.001,10), 
    col  = "red", 
    log  = "x", 
    xlab = "-h", 
    ylab = expression( theta )
)   #
abline( v = 0.01 )


cleanEx()
nameEx("fun.campbell.K.h")
### * fun.campbell.K.h

flush(stderr()); flush(stdout())

### Name: fun.campbell.K.h
### Title: Campbell 1974 function for hydraulic conductivity, K(h)
### Aliases: fun.campbell.K.h

### ** Examples
require("soilwaterfun") 

fun.campbell.K.h( 
    h       = seq(from=0,to=-10,by=-0.1), 
    h.a     = -0.01, 
    Ks      = 10, 
    b.par   = 1/3 
)   #

curve( 
    fun.campbell.K.h( 
        h       = -x, 
        h.a     = -0.01, 
        Ks      = 10, 
        b.par   = 1/3 
    ),  #
    xlim = c(0.001,10), 
    col  = "red", 
    log  = "xy", 
    xlab = "-h", 
    ylab = "K"
)   #
abline( v = 0.01 ) 


cleanEx()
nameEx("fun.campbell.K.theta")
### * fun.campbell.K.theta

flush(stderr()); flush(stdout())

### Name: fun.campbell.K.theta
### Title: Campbell 1974 function for hydraulic conductivity, K(theta)
### Aliases: fun.campbell.K.theta

### ** Examples
require("soilwaterfun") 

fun.campbell.K.theta( 
    theta   = seq(from=0,to=0.5,by=0.1), 
    theta.s = 0.5, 
    Ks      = 10, 
    b.par   = 1/3 
)   #

curve( 
    fun.campbell.K.theta( 
        theta   = x, 
        theta.s = 0.5, 
        Ks      = 10, 
        b.par   = 1/3 
    ),  #
    xlim = c(0.01,0.5), 
    col  = "red", 
    log  = "y", 
    xlab = expression( theta ), 
    ylab = "K"
)   #


cleanEx()
nameEx("fun.campbell.theta.h")
### * fun.campbell.theta.h

flush(stderr()); flush(stdout())

### Name: fun.campbell.theta.h
### Title: Campbell 1974 function for water retension, theta(h)
### Aliases: fun.campbell.theta.h

### ** Examples
require("soilwaterfun") 

fun.campbell.theta.h( 
    h       = seq(from=0,to=-10,by=-0.1), 
    h.a     = -0.01, 
    theta.s = 0.5, 
    b.par   = 1/3 
)   #

curve( 
    fun.campbell.theta.h( 
        h       = -x, 
        h.a     = -0.01, 
        theta.s = 0.5, 
        b.par   = 1/3 
    ), 
    xlim = c(0.001,10), 
    col  = "red", 
    log  = "x", 
    xlab = "-h", 
    ylab = expression( theta )
)   #
abline( v = 0.01 )


cleanEx()
nameEx("fun.h2pF")
### * fun.h2pF

flush(stderr()); flush(stdout())

### Name: fun.h2pF
### Title: Converts h to pF
### Aliases: fun.h2pF

### ** Examples
require( "soilwaterfun" )

fun.h2pF( h = fun.pF2h( pF = c(0,2,4.2) ) )


cleanEx()
nameEx("fun.mualem.vangenuchten.K.h")
### * fun.mualem.vangenuchten.K.h

flush(stderr()); flush(stdout())

### Name: fun.mualem.vangenuchten.K.h
### Title: Mualem (1976) & van Genuchten (1980)'s function K(h) (hydraulic
###   conductivity).
### Aliases: fun.mualem.vangenuchten.K.h

### ** Examples
require( "soilwaterfun" ) 

# Example with the properties of the Footprint soil type P22i, 
# 3rd layer:
fun.mualem.vangenuchten.K.h( 
    h       = -c(0,0.01,0.1,1,10,100,158), 
    Ks      = 28.27612, 
    alpha   = 3.561099, 
    n       = 1.212074  
)   #

curve( 
    fun.mualem.vangenuchten.K.h( 
        h       = -x, 
        Ks      = 28.27612, 
        alpha   = 3.561099, 
        n       = 1.212074  
    ),  #
    xlim = c(0.001,158), 
    col  = "red", 
    log  = "xy", 
    xlab = "-h", 
    ylab = "K"
)   #



cleanEx()
nameEx("fun.pF2h")
### * fun.pF2h

flush(stderr()); flush(stdout())

### Name: fun.pF2h
### Title: Converts pF to h
### Aliases: fun.pF2h

### ** Examples
require( "soilwaterfun" )

fun.pF2h( pF = c(0,2,4.2) ) 


cleanEx()
nameEx("fun.vangenuchten.h.theta")
### * fun.vangenuchten.h.theta

flush(stderr()); flush(stdout())

### Name: fun.vangenuchten.h.theta
### Title: van Genuchten 1980's function h(theta) (water retension).
### Aliases: fun.vangenuchten.h.theta

### ** Examples
require( "soilwaterfun" ) 

# Example with the properties of the Footprint soil type P22i, 
# 3rd layer:
tmp <- fun.vangenuchten.h.theta( 
    theta   = c(0.4162380,0.4149725,0.3983120,0.3073250,0.1946693,0.1197170,0.1086555), 
    alpha   = 3.561099, 
    n       = 1.212074, 
    theta.s = 0.4162380, 
    theta.r = 0  
)   #

round( tmp, 2 ) 

curve( 
    fun.vangenuchten.h.theta( 
        theta   = x, 
        alpha   = 3.561099, 
        n       = 1.212074, 
        theta.s = 0.4162380, 
        theta.r = 0  
    ),  #
    xlim = c(0,0.5), 
    col  = "red", 
    log  = "y", 
    xlab = expression( theta ), 
    ylab = "h" 
)   #



cleanEx()
nameEx("fun.vangenuchten.se.h")
### * fun.vangenuchten.se.h

flush(stderr()); flush(stdout())

### Name: fun.vangenuchten.se.h
### Title: van Genuchten 1980's function for soil relative saturation.
### Aliases: fun.vangenuchten.se.h

### ** Examples
require( "soilwaterfun" ) 

# Example with the properties of the Footprint soil type P22i, 
# 3rd layer:
fun.vangenuchten.se.h( 
    h       = -c(0,0.01,0.1,1,10,100,158), 
    alpha   = 3.561099, 
    n       = 1.212074  
)   #


cleanEx()
nameEx("fun.vangenuchten.se.theta")
### * fun.vangenuchten.se.theta

flush(stderr()); flush(stdout())

### Name: fun.vangenuchten.se.theta
### Title: van Genuchten 1980's function for soil relative saturation
###   (Se=f(theta)).
### Aliases: fun.vangenuchten.se.theta

### ** Examples
require( "soilwaterfun" ) 

# Example with the properties of the Footprint soil type P22i, 
# 3rd layer:
fun.vangenuchten.se.theta( 
    theta   = c(0.4162380,0.4149725,0.3983120,0.3073250,0.1946693,0.1197170,0.1086555), 
    theta.s = 0.4162380, 
    theta.r = 0 
)   #


cleanEx()
nameEx("fun.vangenuchten.theta.h")
### * fun.vangenuchten.theta.h

flush(stderr()); flush(stdout())

### Name: fun.vangenuchten.theta.h
### Title: van Genuchten 1980's function theta(h) (water retension).
### Aliases: fun.vangenuchten.theta.h

### ** Examples
require( "soilwaterfun" ) 

# Example with the properties of the Footprint soil type P22i, 
# 3rd layer:
fun.vangenuchten.theta.h( 
    h       = -c(0,0.01,0.1,1,10,100,158), 
    alpha   = 3.561099, 
    n       = 1.212074, 
    theta.s = 0.4162380, 
    theta.r = 0  
)   #

curve( 
    fun.vangenuchten.theta.h( 
        h       = -x, 
        alpha   = 3.561099, 
        n       = 1.212074, 
        theta.s = 0.4162380, 
        theta.r = 0  
    ),  #
    xlim = c(0.001,158), 
    col  = "red", 
    log  = "x", 
    xlab = "-h", 
    ylab = expression( theta ) 
)   #



### * <FOOTER>
###
cat("Time elapsed: ", proc.time() - get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
