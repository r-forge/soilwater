require( "soilwaterfun" )

fun.pF2h( pF = c(0,2,4.2) ) 
