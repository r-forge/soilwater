pkgname <- "soilwaterptf"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
options(pager = "console")
library('soilwaterptf')

assign(".oldSearch", search(), pos = 'CheckExEnv')
cleanEx()
nameEx("ptf.wosten.alpha")
### * ptf.wosten.alpha

flush(stderr()); flush(stdout())

### Name: ptf.wosten.alpha
### Title: Wosten et al. 1999 PTF for van Genuchten 1980 alpha parameter.
### Aliases: ptf.wosten.alpha

### ** Examples
require( "soilwaterptf" ) 

# Example with the properties of the Footprint soil type P22i:
ptf.wosten.alpha( 
    # layer no:     1    2    3    4    5    6    7    7    8 
    CLAY    = c(   15,  15,  16,  16,  20,  20,  25,  25,  14), 
    BULKD   = c(1.296,1.44,1.48,1.48,1.51,1.51,1.55,1.55,1.56), 
    SILT    = c(   43,  43,  40,  40,  39,  39,  38,  38,  33), 
    OM      = c(    2,1.23, 0.7, 0.7, 0.5, 0.5, 0.4, 0.4, 0.3) * 1.724, 
    topsoil = c(    1,   1,   0,   0,   0,   0,   0,   0,   0)  
)   #



cleanEx()
nameEx("ptf.wosten.ksat")
### * ptf.wosten.ksat

flush(stderr()); flush(stdout())

### Name: ptf.wosten.ksat
### Title: Wosten et al. 1999 PTF for soil's saturated hydraulic
###   conductivity.
### Aliases: ptf.wosten.ksat

### ** Examples
require( "soilwaterptf" ) 

# Example with the properties of the Footprint soil type P22i:
ptf.wosten.ksat( 
    # layer no:     1    2    3    4    5    6    7    7    8 
    CLAY    = c(   15,  15,  16,  16,  20,  20,  25,  25,  14), 
    BULKD   = c(1.296,1.44,1.48,1.48,1.51,1.51,1.55,1.55,1.56), 
    SILT    = c(   43,  43,  40,  40,  39,  39,  38,  38,  33), 
    OM      = c(    2,1.23, 0.7, 0.7, 0.5, 0.5, 0.4, 0.4, 0.3) * 1.724, 
    topsoil = c(    1,   1,   0,   0,   0,   0,   0,   0,   0)  
)   #


cleanEx()
nameEx("ptf.wosten.l")
### * ptf.wosten.l

flush(stderr()); flush(stdout())

### Name: ptf.wosten.l
### Title: Wosten et al. 1999 PTF for van Genuchten 1980 l parameter.
### Aliases: ptf.wosten.l

### ** Examples
require( "soilwaterptf" ) 

# Example with the properties of the Footprint soil type P22i:
ptf.wosten.l( 
    # layer no:     1    2    3    4    5    6    7    7    8 
    CLAY    = c(   15,  15,  16,  16,  20,  20,  25,  25,  14), 
    BULKD   = c(1.296,1.44,1.48,1.48,1.51,1.51,1.55,1.55,1.56), 
    SILT    = c(   43,  43,  40,  40,  39,  39,  38,  38,  33), 
    OM      = c(    2,1.23, 0.7, 0.7, 0.5, 0.5, 0.4, 0.4, 0.3) * 1.724  
)   #


cleanEx()
nameEx("ptf.wosten.n")
### * ptf.wosten.n

flush(stderr()); flush(stdout())

### Name: ptf.wosten.n
### Title: Wosten et al. 1999 PTF for van Genuchten 1980 n parameter.
### Aliases: ptf.wosten.n

### ** Examples
require( "soilwaterptf" ) 

# Example with the properties of the Footprint soil type P22i:
ptf.wosten.n( 
    # layer no:     1    2    3    4    5    6    7    7    8 
    CLAY    = c(   15,  15,  16,  16,  20,  20,  25,  25,  14), 
    BULKD   = c(1.296,1.44,1.48,1.48,1.51,1.51,1.55,1.55,1.56), 
    SILT    = c(   43,  43,  40,  40,  39,  39,  38,  38,  33), 
    OM      = c(    2,1.23, 0.7, 0.7, 0.5, 0.5, 0.4, 0.4, 0.3) * 1.724, 
    topsoil = c(    1,   1,   0,   0,   0,   0,   0,   0,   0)  
)   #


cleanEx()
nameEx("ptf.wosten.theta.s")
### * ptf.wosten.theta.s

flush(stderr()); flush(stdout())

### Name: ptf.wosten.theta.s
### Title: Wosten et al. 1999 PTF for soil's saturated water content.
### Aliases: ptf.wosten.theta.s

### ** Examples
require( "soilwaterptf" ) 

# Example with the properties of the Footprint soil type P22i:
ptf.wosten.theta.s( 
    # layer no:     1    2    3    4    5    6    7    7    8 
    CLAY    = c(   15,  15,  16,  16,  20,  20,  25,  25,  14), 
    BULKD   = c(1.296,1.44,1.48,1.48,1.51,1.51,1.55,1.55,1.56), 
    SILT    = c(   43,  43,  40,  40,  39,  39,  38,  38,  33), 
    OM      = c(    2,1.23, 0.7, 0.7, 0.5, 0.5, 0.4, 0.4, 0.3) * 1.724, 
    topsoil = c(    1,   1,   0,   0,   0,   0,   0,   0,   0)  
)   #


### * <FOOTER>
###
cat("Time elapsed: ", proc.time() - get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
